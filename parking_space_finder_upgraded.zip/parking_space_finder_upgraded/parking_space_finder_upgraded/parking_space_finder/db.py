from backend import db
db.create_all()

